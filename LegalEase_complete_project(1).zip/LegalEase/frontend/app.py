import os,requests,streamlit as st
from dotenv import load_dotenv
from backend.document_utils.formatters import format_docx,format_html_preview,format_pdf,format_txt
load_dotenv()
BACKEND_URL=os.getenv("BACKEND_URL","http://127.0.0.1:8000").rstrip("/")
st.set_page_config(page_title="LegalEase",page_icon="⚖️",layout="wide")
st.markdown("""<style>
.main-title{text-align:center;font-size:2.6rem;font-weight:800}.subtitle{text-align:center;color:#64748b;margin-bottom:1.5rem}
.legal-preview{background:#111827;color:#f8fafc;padding:1.5rem;border-radius:14px;min-height:420px;max-height:620px;overflow-y:auto;line-height:1.65}
.legal-preview h2{color:white}.legal-preview h3{color:#e2e8f0}.notice{background:#fff7ed;border-left:4px solid #f97316;padding:.8rem 1rem;border-radius:8px}
</style>""",unsafe_allow_html=True)
st.markdown('<div class="main-title">⚖️ LegalEase</div>',unsafe_allow_html=True)
st.markdown('<div class="subtitle">AI-powered legal document drafting and export</div>',unsafe_allow_html=True)
st.markdown('<div class="notice"><b>Important:</b> AI-generated drafts should be reviewed by a qualified legal professional before signing or relying on them.</div>',unsafe_allow_html=True)

with st.form("document_form"):
    left,right=st.columns(2)
    with left:
        document_type=st.text_input("Document Type",placeholder="e.g. Freelance Work Contract")
        parties=st.text_area("Parties Involved",placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)",height=130)
        jurisdiction=st.text_input("Jurisdiction (optional)",placeholder="e.g. Tamil Nadu, India")
    with right:
        dates=st.text_input("Effective Date / Dates",placeholder="e.g. 10/04/2026")
        terms=st.text_area("Terms & Conditions",placeholder="Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice",height=190)
    submitted=st.form_submit_button("✨ Generate Document",use_container_width=True)

if submitted:
    missing=[n for n,v in [("Document Type",document_type),("Parties Involved",parties),("Terms & Conditions",terms),("Effective Date / Dates",dates)] if not v.strip()]
    if missing: st.error("Please complete: "+", ".join(missing))
    else:
        try:
            with st.spinner("Generating your document..."):
                r=requests.post(f"{BACKEND_URL}/generate",json={"document_type":document_type.strip(),"parties":parties.strip(),"terms":terms.strip(),"dates":dates.strip(),"jurisdiction":jurisdiction.strip() or "Not specified"},timeout=120)
            if r.ok:
                d=r.json(); st.session_state.update(document=d["content"],document_type=document_type.strip(),terms=terms.strip(),model=d["model"],mock_mode=d["mock_mode"]); st.success("Document generated successfully.")
            else: st.error("Backend error: "+str(r.json().get("detail",r.text)))
        except requests.RequestException as e: st.error("Could not reach FastAPI. Start the backend first."); st.caption(str(e))

if "document" in st.session_state:
    st.divider()
    if st.session_state.get("mock_mode"): st.info("Demo/mock mode is active.")
    else: st.caption("Generated with: "+st.session_state.get("model","unknown"))
    if st.button("✏️ Edit Document"): st.session_state["editing"]=True
    if st.session_state.get("editing"): st.session_state["document"]=st.text_area("Editable Document",st.session_state["document"],height=550)
    else: st.markdown(format_html_preview(st.session_state["document"]),unsafe_allow_html=True)
    st.subheader("Download"); c1,c2,c3=st.columns(3); text=st.session_state["document"]; typ=st.session_state["document_type"]
    safe="".join(ch.lower() if ch.isalnum() else "_" for ch in typ).strip("_") or "legalease_document"
    with c1: st.download_button("⬇️ Download TXT",format_txt(text),f"{safe}.txt","text/plain",use_container_width=True)
    with c2: st.download_button("⬇️ Download DOCX",format_docx(text,typ,st.session_state["terms"]),f"{safe}.docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document",use_container_width=True)
    with c3: st.download_button("⬇️ Download PDF",format_pdf(text,typ),f"{safe}.pdf","application/pdf",use_container_width=True)
st.divider(); st.caption("LegalEase • FastAPI + Streamlit + Google Gemini")
