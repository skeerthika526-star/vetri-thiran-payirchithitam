# LegalEase

AI-powered legal document drafting application based on the supplied project specification.

## Setup in VS Code (Windows PowerShell)
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

Set `GEMINI_API_KEY` in `.env`. The implementation uses the current Google Gen AI Python SDK and defaults to `gemini-2.5-flash`; the supplied document specified the older Gemini 1.5 Pro / `google-generativeai` stack.

For local UI/export testing without a Gemini key, set `MOCK_AI=true`.

## Run
Terminal 1:
```powershell
uvicorn backend.main:app --reload --port 8000
```
Terminal 2:
```powershell
streamlit run frontend/app.py
```

Open `http://localhost:8501`; API docs: `http://127.0.0.1:8000/docs`.

## Test
```powershell
pytest -q
```

## Structure
```text
LegalEase/
├── backend/
│   ├── __init__.py
│   ├── main.py
│   ├── routes.py
│   ├── ai_core/
│   │   ├── __init__.py
│   │   └── gemini_generator.py
│   └── document_utils/
│       ├── __init__.py
│       └── formatters.py
├── frontend/app.py
├── assets/logo.png
├── tests/
├── .env.example
├── .gitignore
├── Dockerfile
├── Procfile
└── requirements.txt
```

## Important
LegalEase is a drafting assistant. AI output may contain errors or omissions.
Review important documents with a qualified legal professional before signing or relying on them.
