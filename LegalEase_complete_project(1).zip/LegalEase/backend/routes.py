from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from backend.ai_core.gemini_generator import GeminiDocumentGenerator

router=APIRouter()
generator=GeminiDocumentGenerator()

class DocumentRequest(BaseModel):
    document_type:str=Field(...,min_length=2,max_length=100)
    parties:str=Field(...,min_length=2,max_length=5000)
    terms:str=Field(...,min_length=2,max_length=10000)
    dates:str=Field(...,min_length=2,max_length=200)
    jurisdiction:Optional[str]=Field("Not specified",max_length=300)

class DocumentResponse(BaseModel):
    document_type:str
    content:str
    model:str
    mock_mode:bool

@router.post("/generate",response_model=DocumentResponse)
def generate_document(request:DocumentRequest):
    try:
        result=generator.generate_document(request.document_type,request.parties,request.terms,request.dates,request.jurisdiction or "Not specified")
        return DocumentResponse(document_type=request.document_type,**result)
    except Exception as exc:
        raise HTTPException(status_code=502,detail=str(exc)) from exc
