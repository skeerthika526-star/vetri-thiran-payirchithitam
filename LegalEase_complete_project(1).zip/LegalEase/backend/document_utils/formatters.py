import html,re
from io import BytesIO
from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches,Pt
from fpdf import FPDF

BASE_DIR=Path(__file__).resolve().parents[2]
LOGO_PATH=BASE_DIR/"assets"/"logo.png"

def sanitize_text(text):
    text=text.replace("\r\n","\n").replace("\r","\n")
    for a,b in {"\u2018":"'","\u2019":"'","\u201c":'"',"\u201d":'"',"\u2013":"-","\u2014":"-","\u2026":"...","\u00a0":" "}.items():
        text=text.replace(a,b)
    return text.strip()

def _lines(text): return [x.strip() for x in sanitize_text(text).split("\n")]
def _heading(line):
    return bool(line) and (bool(re.match(r"^\d+\.\s+.+$",line)) or (line.upper()==line and len(line)<100 and any(c.isalpha() for c in line)))
def _pdf_text(s): return s.encode("latin-1",errors="replace").decode("latin-1")

def format_docx(text,doc_type,terms=""):
    doc=Document(); sec=doc.sections[0]
    sec.top_margin=sec.bottom_margin=Inches(.7); sec.left_margin=sec.right_margin=Inches(.8)
    doc.styles["Normal"].font.name="Times New Roman"; doc.styles["Normal"].font.size=Pt(11)
    if LOGO_PATH.exists():
        p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run().add_picture(str(LOGO_PATH),width=Inches(1.25))
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run(doc_type.upper()); r.bold=True; r.font.size=Pt(16)
    for line in _lines(text):
        if not line: doc.add_paragraph(""); continue
        p=doc.add_paragraph(); r=p.add_run(line); r.font.name="Times New Roman"
        if _heading(line): r.bold=True; r.font.size=Pt(12)
        else: p.paragraph_format.space_after=Pt(5); r.font.size=Pt(11)
    if terms.strip():
        doc.add_page_break(); h=doc.add_paragraph(); h.add_run("TERMS TABLE").bold=True
        table=doc.add_table(rows=1,cols=2); table.style="Table Grid"
        table.rows[0].cells[0].text="No."; table.rows[0].cells[1].text="Term / Condition"
        for i,t in enumerate([x.strip() for x in terms.split(";") if x.strip()],1):
            c=table.add_row().cells; c[0].text=str(i); c[1].text=t
    f=sec.footer.paragraphs[0]; f.alignment=WD_ALIGN_PARAGRAPH.CENTER
    f.add_run("LegalEase - AI-generated draft. Review with a qualified legal professional.").font.size=Pt(8)
    out=BytesIO(); doc.save(out); return out.getvalue()

class LegalEasePDF(FPDF):
    def __init__(self,doc_type): super().__init__(); self.doc_type=doc_type; self.set_auto_page_break(True,18)
    def header(self):
        if LOGO_PATH.exists():
            try:self.image(str(LOGO_PATH),x=95,y=8,w=20)
            except Exception:pass
        self.set_y(30); self.set_font("Helvetica","B",12); self.cell(0,8,_pdf_text(self.doc_type.upper()),align="C"); self.ln(8)
    def footer(self):
        self.set_y(-15); self.set_font("Helvetica","",7); self.cell(0,8,"LegalEase - AI-generated draft. Review with a qualified legal professional.",align="C")

def format_pdf(text,doc_type):
    pdf=LegalEasePDF(doc_type); pdf.add_page()
    for line in _lines(text):
        if not line: pdf.ln(3); continue
        pdf.set_font("Helvetica","B" if _heading(line) else "",11 if _heading(line) else 10)
        pdf.multi_cell(0,7 if _heading(line) else 6,_pdf_text(line)); pdf.ln(1)
    return bytes(pdf.output())

def format_txt(text): return sanitize_text(text).encode("utf-8")

def format_html_preview(text):
    s=html.escape(sanitize_text(text))
    s=re.sub(r"(?m)^(\d+\.\s+.+)$",r"<h3>\1</h3>",s)
    s=re.sub(r"(?m)^([A-Z][A-Z0-9 &()/,-]{2,})$",r"<h2>\1</h2>",s)
    return '<div class="legal-preview">'+s.replace("\n","<br>")+"</div>"
