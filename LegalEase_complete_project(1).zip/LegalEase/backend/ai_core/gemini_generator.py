import os
from dotenv import load_dotenv
load_dotenv()

class GeminiDocumentGenerator:
    def __init__(self):
        self.api_key=os.getenv("GEMINI_API_KEY","").strip()
        self.model=os.getenv("GEMINI_MODEL","gemini-2.5-flash")
        self.mock_ai=os.getenv("MOCK_AI","false").lower()=="true"

    def generate_document(self,document_type,parties,terms,dates,jurisdiction):
        if self.mock_ai:
            return {"content":self._mock(document_type,parties,terms,dates,jurisdiction),"model":"mock","mock_mode":True}
        if not self.api_key:
            raise RuntimeError("GEMINI_API_KEY is missing. Add it to .env or set MOCK_AI=true.")
        from google import genai
        from google.genai import types
        prompt=("You are LegalEase, an AI drafting assistant. Draft a professional editable "
                + document_type + " using only supplied facts. Do not invent material facts. "
                "Missing important facts must be shown as [INSERT ...]. Use numbered sections, "
                "descriptive headings, supplied parties/dates/obligations, and signature blocks "
                "where appropriate. Use governing-law language only if jurisdiction was supplied. "
                "Do not claim the document is legally valid or replace qualified legal advice.\n\n"
                f"Document type: {document_type}\nParties: {parties}\nTerms: {terms}\n"
                f"Effective date/dates: {dates}\nJurisdiction: {jurisdiction}\n\nReturn only the draft document.")
        with genai.Client(api_key=self.api_key) as client:
            response=client.models.generate_content(model=self.model,contents=prompt,
                config=types.GenerateContentConfig(temperature=0.25,max_output_tokens=7000))
        content=(response.text or "").strip()
        if not content: raise RuntimeError("Gemini returned an empty response.")
        return {"content":content,"model":self.model,"mock_mode":False}

    @staticmethod
    def _mock(document_type,parties,terms,dates,jurisdiction):
        clauses=[x.strip() for x in terms.split(";") if x.strip()]
        term_text="\n".join(f"{i}. {x}" for i,x in enumerate(clauses,1)) or "[INSERT TERMS]"
        return (f"{document_type.upper()}\n\nEffective Date: {dates}\n\nPARTIES\n{parties}\n\n"
                f"1. PURPOSE\nThis document records the agreement described by the parties.\n\n"
                f"2. TERMS AND CONDITIONS\n{term_text}\n\n3. JURISDICTION\n{jurisdiction}\n\n"
                "4. GENERAL\nAny missing information should be completed before signing.\n\n"
                "5. SIGNATURES\nParty 1: ______________________________\nName: ________________________________\n"
                "Date: _________________________________\n\nParty 2: ______________________________\n"
                "Name: ________________________________\nDate: _________________________________\n\n"
                "IMPORTANT NOTICE\nThis is a demonstration draft. It is not legal advice and should be reviewed "
                "by a qualified legal professional before use.")
