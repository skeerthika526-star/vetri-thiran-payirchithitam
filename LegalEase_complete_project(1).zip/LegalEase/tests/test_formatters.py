from backend.document_utils.formatters import sanitize_text,format_txt,format_docx,format_pdf
def test_sanitize(): assert sanitize_text("A\r\nB\u2019s")=="A\nB's"
def test_txt(): assert format_txt("Hello")==b"Hello"
def test_docx(): assert format_docx("CONTRACT\n\n1. PURPOSE\nWork.","Contract","Payment")[:2]==b"PK"
def test_pdf(): assert format_pdf("CONTRACT\n\n1. PURPOSE\nWork.","Contract").startswith(b"%PDF")
